//
//  ViewController.h
//  Fitnessapps
//
//  Created by Admin on 05/12/17.
//  Copyright © 2017 webistrasoft.org. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController
- (IBAction)Login_btn:(id)sender;
- (IBAction)Register_btn:(id)sender;

@property (weak, nonatomic) IBOutlet UIButton *forgetpassword_btn;
- (IBAction)Forge_btn:(id)sender;

@end

