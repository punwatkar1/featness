//
//  ResetPassViewController.m
//  Fitnessapps
//
//  Created by Admin on 08/12/17.
//  Copyright © 2017 webistrasoft.org. All rights reserved.
//

#import "ResetPassViewController.h"
#import "ViewController.h"
#import "LoginViewController.h"
#import "MainViewController.h"
#import "SlidemenuViewController.h"
#import "SSSideMenu.h"
@interface ResetPassViewController ()

@end

@implementation ResetPassViewController

- (void)viewDidLoad {
    [super viewDidLoad];
 
    UITapGestureRecognizer *back_btnData2 = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(back_btnData2)];
    back_btnData2.numberOfTapsRequired = 1;
    [self.Back_btn addGestureRecognizer:back_btnData2];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
-(void)back_btnData2
{
    
    CATransition *transition = [CATransition animation];
    transition.duration = 0.30;
    transition.timingFunction = [CAMediaTimingFunction functionWithName:kCAMediaTimingFunctionEaseInEaseOut];
    transition.type = kCATransitionPush;
    transition.subtype = kCATransitionFromLeft;
    [self.view.window.layer addAnimation:transition forKey:nil];
    //MainViewControllerTableview *vc= [self.storyboard instantiateViewControllerWithIdentifier:@"MainViewControllerTableview"];
    //[self presentViewController:vc animated:NO completion:nil];
    [self dismissViewControllerAnimated:NO completion:nil];
}

@end
