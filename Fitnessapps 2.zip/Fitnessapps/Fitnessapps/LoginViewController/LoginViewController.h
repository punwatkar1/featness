//
//  LoginViewController.h
//  Fitnessapps
//
//  Created by Admin on 05/12/17.
//  Copyright © 2017 webistrasoft.org. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface LoginViewController : UIViewController
@property (weak, nonatomic) IBOutlet UIView *back_btn;

@end
