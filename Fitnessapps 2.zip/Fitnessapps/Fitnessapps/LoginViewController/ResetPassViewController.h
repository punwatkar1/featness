//
//  ResetPassViewController.h
//  Fitnessapps
//
//  Created by Admin on 08/12/17.
//  Copyright © 2017 webistrasoft.org. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ResetPassViewController : UIViewController
@property (weak, nonatomic) IBOutlet UIView *Back_btn;

@end
