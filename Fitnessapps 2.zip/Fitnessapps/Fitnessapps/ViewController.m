//
//  ViewController.m
//  Fitnessapps
//
//  Created by Admin on 05/12/17.
//  Copyright © 2017 webistrasoft.org. All rights reserved.
//

#import "ViewController.h"
#import "LoginViewController.h"
#import "ResetPassViewController.h"
#import "MainViewController.h"
#import "SlidemenuViewController.h"
#import "SSSideMenu.h"
@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


- (IBAction)Login_btn:(id)sender {
    CATransition *transition = [CATransition animation];
    transition.duration = 0.20;
    transition.timingFunction = [CAMediaTimingFunction functionWithName:kCAMediaTimingFunctionEaseInEaseOut];
    transition.type = kCATransitionPush;
    transition.subtype = kCATransitionFromRight;
    [self.view.window.layer addAnimation:transition forKey:nil];
    
    MainViewController *VC = [self.storyboard instantiateViewControllerWithIdentifier:@"MainViewController"];
    [self presentViewController:VC animated:true completion:nil];
    
    
}

- (IBAction)Register_btn:(id)sender {
    CATransition *transition = [CATransition animation];
    transition.duration = 0.20;
    transition.timingFunction = [CAMediaTimingFunction functionWithName:kCAMediaTimingFunctionEaseInEaseOut];
    transition.type = kCATransitionPush;
    transition.subtype = kCATransitionFromRight;
    [self.view.window.layer addAnimation:transition forKey:nil];
    
    LoginViewController *VC = [self.storyboard instantiateViewControllerWithIdentifier:@"LoginViewController"];
    [self presentViewController:VC animated:true completion:nil];
    
    
}
- (IBAction)Forge_btn:(id)sender {
    CATransition *transition = [CATransition animation];
    transition.duration = 0.20;
    transition.timingFunction = [CAMediaTimingFunction functionWithName:kCAMediaTimingFunctionEaseInEaseOut];
    transition.type = kCATransitionPush;
    transition.subtype = kCATransitionFromRight;
    [self.view.window.layer addAnimation:transition forKey:nil];
    
    ResetPassViewController *VC = [self.storyboard instantiateViewControllerWithIdentifier:@"ResetPassViewController"];
    [self presentViewController:VC animated:true completion:nil];
    
    
    
}
@end
