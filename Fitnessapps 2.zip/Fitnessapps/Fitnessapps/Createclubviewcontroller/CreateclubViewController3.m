//
//  CreateclubViewController3.m
//  Fitnessapps
//
//  Created by Admin on 08/12/17.
//  Copyright © 2017 webistrasoft.org. All rights reserved.
//

#import "CreateclubViewController3.h"

#import "MainViewController.h"
#import "SlidemenuViewController.h"
#import "SSSideMenu.h"
#import "CreateclubViewController1.h"
#import "CreateclubViewController2.h"
#import "CreateclubViewController3.h"
#import "SearchViewController.h"
@interface CreateclubViewController3 ()

@end

@implementation CreateclubViewController3

- (void)viewDidLoad {
    [super viewDidLoad];
    UITapGestureRecognizer *Confirm_btnpped = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(Confirm_btnpped)];
    Confirm_btnpped.numberOfTapsRequired = 1;
    [self.Confirm_btn addGestureRecognizer:Confirm_btnpped];
    
    
    
    UITapGestureRecognizer *Next_btntnpped = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(Next_btntnpped)];
    Next_btntnpped.numberOfTapsRequired = 1;
    [self.Next_btn addGestureRecognizer:Next_btntnpped];
    
    
    
    _Payment_view.hidden=YES;
    _Conpaymnt_view.hidden=YES;
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
-(void)Next_btntnpped
{
    _Payment_view.hidden=NO;
    _Conpaymnt_view.hidden=NO;
}
-(void)Confirm_btnpped
{
    CATransition *transition = [CATransition animation];
    transition.duration = 0.20;
    transition.timingFunction = [CAMediaTimingFunction functionWithName:kCAMediaTimingFunctionEaseInEaseOut];
    transition.type = kCATransitionPush;
    transition.subtype = kCATransitionFromRight;
    [self.view.window.layer addAnimation:transition forKey:nil];
    
    MainViewController *VC = [self.storyboard instantiateViewControllerWithIdentifier:@"MainViewController"];
    [self presentViewController:VC animated:true completion:nil];
}
/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
