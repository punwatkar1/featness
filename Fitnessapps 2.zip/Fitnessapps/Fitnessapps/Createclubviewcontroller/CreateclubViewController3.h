//
//  CreateclubViewController3.h
//  Fitnessapps
//
//  Created by Admin on 08/12/17.
//  Copyright © 2017 webistrasoft.org. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CreateclubViewController3 : UIViewController
@property (weak, nonatomic) IBOutlet UIView *Next_btn;
@property (weak, nonatomic) IBOutlet UIView *Payment_view;
@property (weak, nonatomic) IBOutlet UIView *Conpaymnt_view;
@property (weak, nonatomic) IBOutlet UIView *Confirm_btn;

@end
