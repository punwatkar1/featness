//
//  CreateclubViewController2.m
//  Fitnessapps
//
//  Created by Admin on 08/12/17.
//  Copyright © 2017 webistrasoft.org. All rights reserved.
//


#import "MainViewController.h"
#import "SlidemenuViewController.h"
#import "SSSideMenu.h"
#import "CreateclubViewController1.h"
#import "CreateclubViewController2.h"
#import "CreateclubViewController3.h"
#import "SearchViewController.h"
@interface CreateclubViewController2 ()

@end

@implementation CreateclubViewController2

- (void)viewDidLoad {
    [super viewDidLoad];
    UITapGestureRecognizer *Back_btnpped = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(Back_btnpped)];
    Back_btnpped.numberOfTapsRequired = 1;
    [self.back_btn addGestureRecognizer:Back_btnpped];
    
    
    
    UITapGestureRecognizer *Next_btntnpped = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(Next_btntnpped)];
    Next_btntnpped.numberOfTapsRequired = 1;
    [self.Next_btn addGestureRecognizer:Next_btntnpped];
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
-(void)Next_btntnpped
{
    CATransition *transition = [CATransition animation];
    transition.duration = 0.20;
    transition.timingFunction = [CAMediaTimingFunction functionWithName:kCAMediaTimingFunctionEaseInEaseOut];
    transition.type = kCATransitionPush;
    transition.subtype = kCATransitionFromRight;
    [self.view.window.layer addAnimation:transition forKey:nil];
    
    CreateclubViewController3 *VC = [self.storyboard instantiateViewControllerWithIdentifier:@"CreateclubViewController3"];
    [self presentViewController:VC animated:true completion:nil];
    
}
-(void)Back_btnpped
{
    CATransition *transition = [CATransition animation];
    transition.duration = 0.30;
    transition.timingFunction = [CAMediaTimingFunction functionWithName:kCAMediaTimingFunctionEaseInEaseOut];
    transition.type = kCATransitionPush;
    transition.subtype = kCATransitionFromLeft;
    [self.view.window.layer addAnimation:transition forKey:nil];
    //MainViewControllerTableview *vc= [self.storyboard instantiateViewControllerWithIdentifier:@"MainViewControllerTableview"];
    //[self presentViewController:vc animated:NO completion:nil];
    [self dismissViewControllerAnimated:NO completion:nil];
}

@end
