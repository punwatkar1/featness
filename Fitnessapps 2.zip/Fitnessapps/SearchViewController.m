//
//  SearchViewController.m
//  Fitnessapps
//
//  Created by Admin on 06/12/17.
//  Copyright © 2017 webistrasoft.org. All rights reserved.
//
#import "ViewController.h"
#import "LoginViewController.h"
#import "ResetPassViewController.h"

#import "MainViewController.h"
#import "SlidemenuViewController.h"
#import "SSSideMenu.h"
#import "CreateclubViewController1.h"
#import "CreateclubViewController2.h"
#import "CreateclubViewController3.h"
#import "SearchViewController.h"

#import "SearchViewController.h"

@interface SearchViewController ()

@end

@implementation SearchViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    UITapGestureRecognizer *Back_btnpped = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(Back_btnpped)];
    Back_btnpped.numberOfTapsRequired = 1;
    [self.Back_btn addGestureRecognizer:Back_btnpped];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
-(void)Back_btnpped
{
    CATransition *transition = [CATransition animation];
    transition.duration = 0.30;
    transition.timingFunction = [CAMediaTimingFunction functionWithName:kCAMediaTimingFunctionEaseInEaseOut];
    transition.type = kCATransitionPush;
    transition.subtype = kCATransitionFromLeft;
    [self.view.window.layer addAnimation:transition forKey:nil];
    //MainViewControllerTableview *vc= [self.storyboard instantiateViewControllerWithIdentifier:@"MainViewControllerTableview"];
    //[self presentViewController:vc animated:NO completion:nil];
    [self dismissViewControllerAnimated:NO completion:nil];
}

@end
