//
//  SearchViewController.h
//  Fitnessapps
//
//  Created by Admin on 06/12/17.
//  Copyright © 2017 webistrasoft.org. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SearchViewController : UIViewController
@property (weak, nonatomic) IBOutlet UIView *Back_btn;

@end
