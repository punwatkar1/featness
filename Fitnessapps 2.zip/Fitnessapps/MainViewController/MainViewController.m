//
//  MainViewController.m
//  Fitnessapps
//
//  Created by Admin on 06/12/17.
//  Copyright © 2017 webistrasoft.org. All rights reserved.
//
#import "ViewController.h"
#import "LoginViewController.h"
#import "ResetPassViewController.h"

#import "MainViewController.h"
#import "SlidemenuViewController.h"
#import "SSSideMenu.h"
#import "CreateclubViewController1.h"
#import "CreateclubViewController2.h"
#import "CreateclubViewController3.h"
#import "SearchViewController.h"

@interface MainViewController ()
{
    
}
@property UITableViewController *sideMenu;
@property SSSideMenu *sideMenus;
@end

@implementation MainViewController
- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
    }
    return self;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    //...........slide menu............
    _sideMenu = [self.storyboard instantiateViewControllerWithIdentifier:@"SlidemenuViewController"];
    
    if (! _sideMenus) {
        _sideMenus = [[SSSideMenu alloc] setupSSSideMenuWithSize:CGSizeMake(290, self.view.frame.size.height)];
        
        [_sideMenus initSSSideMenuWithSwipeOnSide:@"Both" onView:self forMenu:_sideMenu];
    }
    
    //.................................................
    
    
    UITapGestureRecognizer *searchBtnapped = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(searchBtnapped)];
    searchBtnapped.numberOfTapsRequired = 1;
    [self.SearchButton addGestureRecognizer:searchBtnapped];
    
    self.AnimationView.hidden = YES;
    
    
    
    
    UITapGestureRecognizer *menuBtnapped = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(menuBtnapped)];
    menuBtnapped.numberOfTapsRequired = 1;
    [self.menuBtnView addGestureRecognizer:menuBtnapped];
    
    UITapGestureRecognizer *backSearchBtnapped = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(backSearchBtnapped)];
    backSearchBtnapped.numberOfTapsRequired = 1;
    [self.AnimationView addGestureRecognizer:backSearchBtnapped];
    
    
    UITapGestureRecognizer *Search_btnapped = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(Search_btnapped)];
    Search_btnapped.numberOfTapsRequired = 1;
    [self.Search_btn addGestureRecognizer:Search_btnapped];
    
    
    UITapGestureRecognizer *home_btnapped = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(home_btnapped)];
    home_btnapped.numberOfTapsRequired = 1;
    [self.home_btn addGestureRecognizer:home_btnapped];
    
    
    
    
    UITapGestureRecognizer *Createclub_btnpped = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(Createclub_btnpped)];
    Createclub_btnpped.numberOfTapsRequired = 1;
    [self.Createclub_btn addGestureRecognizer:Createclub_btnpped];
    
    
 

}
///////.......search animation..................
-(void)searchBtnapped
{
    self.AnimationView.hidden = NO;
    
    self.leadingSearchBar.constant = 0;
    [UIView animateWithDuration:0.5 animations:^{
        
        [self.AnimationView layoutIfNeeded];
    _searchTextField.placeholder = @"Search";
        
    }];
    
    
}
-(void)backSearchBtnapped
{
    self.AnimationView.hidden = YES;
    self.leadingSearchBar.constant = 320;
    [UIView animateWithDuration:0.5 animations:^{
        [self.AnimationView layoutIfNeeded];
    _searchTextField.placeholder = @"Search";
        
    }];
    
    
}
//.................................................

-(BOOL)prefersStatusBarHidden {
    
    return YES;
}
-(void)menuBtnapped
{
    
   
}
-(void)Search_btnapped
{
    CATransition *transition = [CATransition animation];
    transition.duration = 0.20;
    transition.timingFunction = [CAMediaTimingFunction functionWithName:kCAMediaTimingFunctionEaseInEaseOut];
    transition.type = kCATransitionPush;
    transition.subtype = kCATransitionFromRight;
    [self.view.window.layer addAnimation:transition forKey:nil];
    
    SearchViewController *VC = [self.storyboard instantiateViewControllerWithIdentifier:@"SearchViewController"];
    [self presentViewController:VC animated:true completion:nil];
    
}
-(void)home_btnapped
{
    CATransition *transition = [CATransition animation];
    transition.duration = 0.20;
    transition.timingFunction = [CAMediaTimingFunction functionWithName:kCAMediaTimingFunctionEaseInEaseOut];
    transition.type = kCATransitionPush;
    transition.subtype = kCATransitionFromRight;
    [self.view.window.layer addAnimation:transition forKey:nil];
    
    MainViewController *VC = [self.storyboard instantiateViewControllerWithIdentifier:@"MainViewController"];
    [self presentViewController:VC animated:true completion:nil];
    
}
-(void)Createclub_btnpped
{
    CATransition *transition = [CATransition animation];
    transition.duration = 0.20;
    transition.timingFunction = [CAMediaTimingFunction functionWithName:kCAMediaTimingFunctionEaseInEaseOut];
    transition.type = kCATransitionPush;
    transition.subtype = kCATransitionFromRight;
    [self.view.window.layer addAnimation:transition forKey:nil];
    
    CreateclubViewController1 *VC = [self.storyboard instantiateViewControllerWithIdentifier:@"CreateclubViewController1"];
    [self presentViewController:VC animated:true completion:nil];
    
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

- (IBAction)Menu_btn:(id)sender {
    // Side menu LEFT
    [_sideMenus openSideMenuViaButtonFor:self andSideMenu:_sideMenu fromSide:@"Left"];

}
@end
