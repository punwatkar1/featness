//
//  MainViewController.h
//  Fitnessapps
//
//  Created by Admin on 06/12/17.
//  Copyright © 2017 webistrasoft.org. All rights reserved.
//

#import <UIKit/UIKit.h>
#define IS_IPAD_DEVICE                      UI_USER_INTERFACE_IDIOM() == UIUserInterfaceIdiomPad
@interface MainViewController : UIViewController
@property (weak, nonatomic) IBOutlet UIView *SearchButton;
@property (weak, nonatomic) IBOutlet UIView *FullView;
@property (weak, nonatomic) IBOutlet UIView *AnimationView;
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *leadingSearchBar;
@property (weak, nonatomic) IBOutlet UITextField *searchTextField;
@property (weak, nonatomic) IBOutlet UIView *menuBtnView;
- (IBAction)Menu_btn:(id)sender;
@property (weak, nonatomic) IBOutlet UIView *Createclub_btn;

//............menu btns...........
@property (weak, nonatomic) IBOutlet UIView *home_btn;
@property (weak, nonatomic) IBOutlet UIView *Search_btn;
@property (weak, nonatomic) IBOutlet UIView *Fav_btn;
@property (weak, nonatomic) IBOutlet UIView *Setting_btn;














@end
